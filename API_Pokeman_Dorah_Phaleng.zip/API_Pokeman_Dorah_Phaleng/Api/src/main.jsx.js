import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import App from './App';
import {Queryclient, QueryClientProvider} from 'react--query';
import axios from 'axios';

axios.defaults.baseURL ='http://localhost:8080';

const queryClient = new queryClient();

ReactDOM.render(
	<React.StrictMode>
	<QueryClientProvider client={queryClient}>
	</QueryClientProvider>
	<App/>
	</React.StrictMode>,
	document.getElementById('root'),
);