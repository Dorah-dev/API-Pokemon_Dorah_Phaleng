import com.pokemon.api.PokemonService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;


import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnetcion;
import java.util.Base64;
import java.util.List;

@SpringBootApplication(scanBasePackages = {"com.pokemon.api", "com.pokemon.db"})

public class seedDB {

	@Autowired
private PokemonService service;

private static class PokemonListEntry{
	public String url;
}
private static class PokemonList{
	public List<seedDB.PokemonListEntry>results;
}

private static class PokemonImage{
	public String front_default;
	public String back_default;
}
private static class PokemonImage{
	public string name;
	public seedDB.PokemonImage sprites; 
}


public static void main(string[] args){
	SpringApplication.run(seedDB.class ,args);
}
@Bean
InitializingBean seed(){
	return () -> {
	  RestTemplate restTemplate = new RestTemplate();
	  PokemonListResponse plr = restTemplate.getForObject(url: "https://pokeapi.co/api/v2/pokemon?Limit=10",PokemonListResponse.class);

plr.results.forEach(p -> {
	PokemonEntry entry = restTemplate.getForObject(p.url,PokemonEntry.class);

	String name = entry.name;
	String imagefront = getBase64(entry.sprites.front_default);
	String imageback = getBase64(entry.sprites.back_defaul);

Pokemon pokemon = new Pokemon(name, imagefront,imageback, quantity: 0);
service.create(pokemon);

	});	  
	};
}
private String getBase64(String url){
	try{
	URL imageUrl = new URL(url);
	URLConnection con = imageUrl.openConnection();
	InputStream is = con.getInputStream();
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	byte[] buffer = new byte[1024];
	int read = 0;
	while ((read = is.read(buffer, off:0, buffer.length)) != -1){
	baos.write(buffer, off:0, read);

	}
	baos.flush();
	return String.format("data:image/png;base64,%s", Base64.getEncoder().encodeToString()));

	}catch (Exception e) {

	return null;
	}


	}catch (Exception e){
	return null;
	}
}
}