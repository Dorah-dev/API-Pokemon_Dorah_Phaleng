export default function PokemonInfo({pokemon}){
	return (
	<div className="border rounded-g text-center cursor-point transition hover:border-y-purple-200">
	<div className="p-1">
		<div className="flex flex-row justify-center">
		<img className="w-1/2"  src={pokemon.imagefront}/>
		<img className="w-1/2" src={pokemon.imageback} />
		</div>

	<h2 className="text-g font-bold mb-0">{pokemon.name}</h2>
	<small className="block mb-4">{pokemon.quantity}</small>
	</div>
	</div>
	);
	}
	)
}
