import {PlusIcon,MinusIcon,XIcon,ExclamationIcon,TrashIcon} from '@heroicons/react/outline';
import useUpdatePokemon from '../hooks/useUpdatePokemon';

export default function PokemonInfo({pokemon}){
	const [showDetail, setShowDetail] = useState();
	const mutationUpdatePokemon = useUpdatePokemon();
	const mutationDeletePokemon = useDeletePokemon();


	const updateQuantity = (id, newQuantity) => {
		if (newQuantity < 0){
			return;
		}
		mutationUpdatePokemon.mutate({id,quantity: newQuantity});
	};


	return (
	<div className="border rounded-g text-center cursor-point transition hover:border-y-purple-200">
	<div className="p-1">
		<div className="flex flex-row justify-center">
		<img className="w-1/2"  src={pokemon.imagefront}/>
		<img className="w-1/2" src={pokemon.imageback} />
		</div>

	<h2 className="text-g font-bold mb-0">{pokemon.name}</h2>
	<small className="block mb-4">{pokemon.quantity}</small>
	</div>
	<div className="border-t flex flex-row">
	<button className="flex items-center justify-center w-1/2 py-2 border-r font-bold
	 transition hover:bg-slate-200" 
	onClick={() => setShowDetai(setShowDetail(showDetail === pokemon.id? null :pokemon.id))}>
	<plusIcon="h-3 w-3" />
	</button>
		<button className="flex items-center justify-center w-1/2 py-2 border-r font-bold transition hover:bg-slate-200" 
		onClick={() => updateQuantity}>
		  <MinusIcon="h-3 w-3" />
		  </button>
	</div>
	{showDetail ==pokemon.id ?(
		<div className='absolute top-0 left-0 round-1g w-full backdrop-blur-md'):null}
	<button className ="absolute top-1 right-1" onClick={() => setShowDetail(null)}>
	<XIcon className= "h-5 w-5"/>
	</button>
	<span className="font-bold mb -4">Quantity:  {pokemon.quantity</span>}
	<button className='flex items-center justify-center rounded-1g bg-rose-600 text-white font-bold px-4 py-2 transition hover:bg-rose-700 mb-3" onClick={() => updateQuantity(pokemon.id,0)}
	disable={mutationUpdatePokemon,isLoading}>
	<ExclamationIcon className = "h-5 w-5 mr-1"/>
	<span> reset</span>
	 </button>
	 <div className ="w-full border-t">
	 <button className='flex items-center justify-center rounded-1g bg-yellow-600 text-white font-bold px-4 py-2 transition hover:bg-yellow-700 mb-3" 
	 onClick={() => handleDelete(pokemon.id,0)}
	disable={mutationUpdatePokemon,isLoading}>
	<ExclamationIcon className = "h-5 w-5 mr-1"/>
	<span> delete</span>

	 </div>
</div>
	) : null }
	);

	}
	

